# Benchmarking

The multievolve_hyperparameter_tuning.py script can be used to train the models for benchmarking MULTI-evolve.

# Data

Large datasets are not included in this repository due to size constraints. Please download DMS dataset files from Zenodo (10.5281/zenodo.17620759) and place in:
- `data/benchmark/datasets/`
