from multievolve.predictors.base_regressors import *
from multievolve.predictors.gaussian_process_regressors import *
from multievolve.predictors.neural_net_regressors import *